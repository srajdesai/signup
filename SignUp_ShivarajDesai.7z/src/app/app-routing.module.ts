import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path:'',
    redirectTo :'/sign-up',
    pathMatch:'full'
  },
  {
    path:'sign-up',
    // loadChildren:()=> import('./sign-up-form/sign-up-form.module').then(m=>m.SignUpFormModule)
    loadChildren:()=> import('./sing-up-form/sign-up-form.module').then(m=>m.SignUpFormModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
