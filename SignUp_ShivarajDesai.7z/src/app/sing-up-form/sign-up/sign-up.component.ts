import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {
  userDetails:FormGroup;
  isSelected=true;
  constructor(private fb:FormBuilder) { }

  ngOnInit(): void {
    this.userDetails = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['',Validators.required],
      email:['',[Validators.required,Validators.email]],
      jobtitle: ['',Validators.required],
      company: ['',Validators.required],
      noofemp: ['',Validators.required],
      ctivendor: ['',Validators.required],
      crmvendor: ['',Validators.required],
      country: ['',Validators.required],
      mobile:['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
    });
  }

  jobTitle=['UI Developer','Java Developer', '.net Developer']
country=[ 'India','USA','France','China']
empNo=['1','5','10','20','25']

}
